package AbstractFactory_Pattern;

public class FactoryProducer {
    public static abstractFactory getFactory(boolean big){
        if(big){
            return new bigFactory();
        }
        else{
            return new smallFactory();
        }
    }

}
