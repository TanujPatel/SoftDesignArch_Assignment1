package AbstractFactory_Pattern;

public class bigFactory  extends abstractFactory{
    @Override
    public factoriesProduct getProducts(String productType) {
        if (productType.equalsIgnoreCase("table")) {
            return new bigTables();
        } else if (productType.equalsIgnoreCase("tv")) {
            return new tv75inch();
        }
        return null;
    }
}
