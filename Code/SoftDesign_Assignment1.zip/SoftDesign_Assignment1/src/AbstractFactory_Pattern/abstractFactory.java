package AbstractFactory_Pattern;

public abstract class abstractFactory {
    abstract factoriesProduct getProducts(String productType);
}
