package AbstractFactory_Pattern;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class bigTables  implements factoriesProduct{
    @Override
    public void printProduct(){

        String price="0";

        try{
            File obj=new File("priceDatabase.txt");
            Scanner sc = new Scanner(obj);

            while(sc.hasNext()){
                String productName=sc.next();
                if (productName.equalsIgnoreCase("bigtable")){
                    price=sc.next();
                }
            }
            sc.close();
        }
        catch(FileNotFoundException e){
            System.out.println("ERROR");
            e.printStackTrace();
        }

        System.out.println("Price of big tables are: $"+price);
    }

}
