package AbstractFactory_Pattern;

public interface factoriesProduct {
    void printProduct() throws Exception;
}
