package AbstractFactory_Pattern;

public class smallFactory extends abstractFactory {
    @Override
    public factoriesProduct getProducts(String productType){
        if(productType.equalsIgnoreCase("table")){
            return new smallTables();
        }
        else if(productType.equalsIgnoreCase("tv")){
            return new tv45inch();
        }
        return null;
    }
}
